-- this file can be deleted if it is not used
local onCityProduction = {}

---&autoDoc onCityProduction
function onCityProduction.onCityProduction(city,prod)
    --civ.ui.text("City production separate file")


end
---&endAutoDoc

return onCityProduction
