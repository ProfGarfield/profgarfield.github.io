-- This file can be deleted if it is not being used.
local register = {}

---&autoDoc onCityDestroyed
-- This function will be registered for the onCityDestroyed
-- execution point
function register.onCityDestroyed(city)
    --civ.ui.text("on city destroyed separate file")
end
---&endAutoDoc

return register
