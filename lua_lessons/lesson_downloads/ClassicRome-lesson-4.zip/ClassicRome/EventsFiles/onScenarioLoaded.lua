-- This file can be deleted if it is not used
local register = {}

---&autoDoc onScenarioLoaded
function register.onScenarioLoaded()
    --civ.ui.text("on scenario loaded separate event file")

end
---&endAutoDoc

return register
