-- this file can be deleted if it is not necessary.
local register = {}

---&autoDoc onCityTaken
function register.onCityTaken(city,defender)
    --civ.ui.text("city taken separate file test")

end
---&endAutoDoc

return register
