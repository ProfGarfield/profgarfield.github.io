-- this file can be deleted if it is not being used
local register = {}

---&autoDoc onCityProcessed
function register.onCityProcessed(city)
    --civ.ui.text("city processed separate file")

end
---&endAutoDoc

return register
