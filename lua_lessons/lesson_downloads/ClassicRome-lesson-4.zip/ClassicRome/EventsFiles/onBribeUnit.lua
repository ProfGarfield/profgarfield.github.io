-- This file can be deleted if it is not used.
local register = {}

---&autoDoc onBribeUnit
function register.onBribeUnit(unit,previousOwner)
    --civ.ui.text("On bribe unit separate file")
end
---&endAutoDoc

return register
