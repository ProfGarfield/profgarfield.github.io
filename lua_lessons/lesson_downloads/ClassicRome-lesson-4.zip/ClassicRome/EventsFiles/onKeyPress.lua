-- this file can be deleted if it is not being used
local register = {}

---&autoDoc onKeyPress
function register.onKeyPress(keyCode)
    --civ.ui.text("key press test separate file")
end
---&endAutoDoc

return register
