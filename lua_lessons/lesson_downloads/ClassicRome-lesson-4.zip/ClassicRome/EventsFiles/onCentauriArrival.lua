-- this file can be deleted if it is not being used.
local register = {}

---&autoDoc onCentauriArrival
function register.onCentauriArrival(tribe)
    --civ.ui.text("centauri arrival separate file")

end
---&endAutoDoc

return register
