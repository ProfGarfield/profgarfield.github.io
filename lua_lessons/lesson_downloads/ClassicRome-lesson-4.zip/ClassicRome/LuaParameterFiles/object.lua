local data = require("data")
local text = require("text")
local gen = require("generalLibrary")

---@class object table
local object = gen.makeDataTable({},"object")
-- This line forbids reassignment of keys of the object table
-- This should prevent errors
gen.forbidReplacement(object)

-- Civilization Advances
-- recommended key prefix 'a'

object.aAdvancedFlight          = civ.getTech(0) --[[@as techObject]]
object.aAlphabet                = civ.getTech(1) --[[@as techObject]]
object.aAmphibiousWarfare       = civ.getTech(2) --[[@as techObject]]
object.aAstronomy               = civ.getTech(3) --[[@as techObject]]
object.aAtomicTheory            = civ.getTech(4) --[[@as techObject]]
object.aAutomobile              = civ.getTech(5) --[[@as techObject]]   --Automobile
object.aBanking                 = civ.getTech(6) --[[@as techObject]]
object.aBridgeBuilding          = civ.getTech(7) --[[@as techObject]]   --Bridge Building
object.aBronzeWorking           = civ.getTech(8) --[[@as techObject]]
object.aCeremonialBurial        = civ.getTech(9) --[[@as techObject]]
object.aChemistry               = civ.getTech(10) --[[@as techObject]]
object.aChivalry                = civ.getTech(11) --[[@as techObject]]
object.aCodeofLaws              = civ.getTech(12) --[[@as techObject]]
object.aCombinedArms            = civ.getTech(13) --[[@as techObject]]
object.aCombustion              = civ.getTech(14) --[[@as techObject]]
object.aCommunism               = civ.getTech(15) --[[@as techObject]]
object.aComputers               = civ.getTech(16) --[[@as techObject]]
object.aConscription            = civ.getTech(17) --[[@as techObject]]
object.aConstruction            = civ.getTech(18) --[[@as techObject]]
object.aCorporation             = civ.getTech(19) --[[@as techObject]]
object.aCurrency                = civ.getTech(20) --[[@as techObject]]
object.aDemocracy               = civ.getTech(21) --[[@as techObject]]
object.aEconomics               = civ.getTech(22) --[[@as techObject]]
object.aElectricity             = civ.getTech(23) --[[@as techObject]]
object.aElectronics             = civ.getTech(24) --[[@as techObject]]
object.aEngineering             = civ.getTech(25) --[[@as techObject]]
object.aEnvironmentalism        = civ.getTech(26) --[[@as techObject]]
object.aEspionage               = civ.getTech(27) --[[@as techObject]]
object.aExplosives              = civ.getTech(28) --[[@as techObject]]
object.aFeudalism               = civ.getTech(29) --[[@as techObject]]
object.aFlight                  = civ.getTech(30) --[[@as techObject]]
object.aFundamentalism          = civ.getTech(31) --[[@as techObject]]
object.aFusionPower             = civ.getTech(32) --[[@as techObject]]
object.aGeneticEngineering      = civ.getTech(33) --[[@as techObject]]
object.aGuerrillaWarfare        = civ.getTech(34) --[[@as techObject]]
object.aGunpowder               = civ.getTech(35) --[[@as techObject]]
object.aHorsebackRiding         = civ.getTech(36) --[[@as techObject]]
object.aIndustrialization       = civ.getTech(37) --[[@as techObject]]
object.aInvention               = civ.getTech(38) --[[@as techObject]]
object.aIronWorking             = civ.getTech(39) --[[@as techObject]]
object.aLaborUnion              = civ.getTech(40) --[[@as techObject]]
object.aLaser                   = civ.getTech(41) --[[@as techObject]]
object.aLeadership              = civ.getTech(42) --[[@as techObject]]
object.aLiteracy                = civ.getTech(43) --[[@as techObject]]
object.aMachineTools            = civ.getTech(44) --[[@as techObject]]
object.aMagnetism               = civ.getTech(45) --[[@as techObject]]
object.aMapMaking               = civ.getTech(46) --[[@as techObject]]
object.aMasonry                 = civ.getTech(47) --[[@as techObject]]
object.aMassProduction          = civ.getTech(48) --[[@as techObject]]
object.aMathematics             = civ.getTech(49) --[[@as techObject]]
object.aMedicine                = civ.getTech(50) --[[@as techObject]]
object.aMetallurgy              = civ.getTech(51) --[[@as techObject]]
object.aMiniaturization         = civ.getTech(52) --[[@as techObject]]
object.aMobileWarfare           = civ.getTech(53) --[[@as techObject]]
object.aMonarchy                = civ.getTech(54) --[[@as techObject]]
object.aMonotheism              = civ.getTech(55) --[[@as techObject]]
object.aMysticism               = civ.getTech(56) --[[@as techObject]]
object.aNavigation              = civ.getTech(57) --[[@as techObject]]
object.aNuclearFission          = civ.getTech(58) --[[@as techObject]]
object.aNuclearPower            = civ.getTech(59) --[[@as techObject]]
object.aPhilosophy              = civ.getTech(60) --[[@as techObject]]
object.aPhysics                 = civ.getTech(61) --[[@as techObject]]
object.aPlastics                = civ.getTech(62) --[[@as techObject]]
object.aPlumbing                = civ.getTech(63) --[[@as techObject]]
object.aPolytheism              = civ.getTech(64) --[[@as techObject]]
object.aPottery                 = civ.getTech(65) --[[@as techObject]]
object.aRadio                   = civ.getTech(66) --[[@as techObject]]
object.aRailroad                = civ.getTech(67) --[[@as techObject]]
object.aRecycling               = civ.getTech(68) --[[@as techObject]]
object.aRefining                = civ.getTech(69) --[[@as techObject]]
object.aRefrigeration           = civ.getTech(70) --[[@as techObject]]
object.aRepublic                = civ.getTech(71) --[[@as techObject]]
object.aRobotics                = civ.getTech(72) --[[@as techObject]]
object.aRocketry                = civ.getTech(73) --[[@as techObject]]
object.aSanitation              = civ.getTech(74) --[[@as techObject]]
object.aSeafaring               = civ.getTech(75) --[[@as techObject]]
object.aSpaceFlight             = civ.getTech(76) --[[@as techObject]]
object.aStealth                 = civ.getTech(77) --[[@as techObject]]
object.aSteamEngine             = civ.getTech(78) --[[@as techObject]]
object.aSteel                   = civ.getTech(79) --[[@as techObject]]
object.aSuperconductor          = civ.getTech(80) --[[@as techObject]]
object.aTactics                 = civ.getTech(81) --[[@as techObject]]
object.aTheology                = civ.getTech(82) --[[@as techObject]]
object.aTheoryofGravity         = civ.getTech(83) --[[@as techObject]]
object.aTrade                   = civ.getTech(84) --[[@as techObject]]
object.aUniversity              = civ.getTech(85) --[[@as techObject]]
object.aWarriorCode             = civ.getTech(86) --[[@as techObject]]
object.aWheel                   = civ.getTech(87) --[[@as techObject]]
object.aWriting                 = civ.getTech(88) --[[@as techObject]]
object.aFutureTechnology        = civ.getTech(89) --[[@as techObject]]
object.aUserDefTechA            = civ.getTech(90) --[[@as techObject]]
object.aUserDefTechB            = civ.getTech(91) --[[@as techObject]]
object.aUserDefTechC            = civ.getTech(92) --[[@as techObject]]
object.aExtraAdvance1           = civ.getTech(93) --[[@as techObject]]
object.aExtraAdvance2           = civ.getTech(94) --[[@as techObject]]
object.aExtraAdvance3           = civ.getTech(95) --[[@as techObject]]
object.aExtraAdvance4           = civ.getTech(96) --[[@as techObject]]
object.aExtraAdvance5           = civ.getTech(97) --[[@as techObject]]
object.aExtraAdvance6           = civ.getTech(98) --[[@as techObject]]
object.aExtraAdvance7           = civ.getTech(99) --[[@as techObject]]

-- Map Locations (tiles/squares)
-- recommended key prefix 'l'


-- Locations of cities starting the scenario owned by the Barbarians:


-- Locations of cities starting the scenario owned by the Romans:

object.lRome                    =civ.getTile(40,28,0)
object.lNeapolis                =civ.getTile(45,37,0)
object.lHeraclea                =civ.getTile(49,43,0)
object.lSena                    =civ.getTile(42,22,0)
object.lPisae                   =civ.getTile(38,20,0)
object.lTarracina               =civ.getTile(41,33,0)

-- Locations of cities starting the scenario owned by the Carthaginians:

object.lCarthage                =civ.getTile(36,62,0)
object.lLilybaeum               =civ.getTile(41,53,0)
object.lGades                   =civ.getTile(3,57,0)
object.lCaralis                 =civ.getTile(36,44,0)
object.lLeptis                  =civ.getTile(40,72,0)
object.lHippoRegius             =civ.getTile(31,61,0)

-- Locations of cities starting the scenario owned by the Macedonian Greeks:

object.lPella                   =civ.getTile(57,31,0)
object.lAthens                  =civ.getTile(62,44,0)
object.lDemetrias               =civ.getTile(59,37,0)
object.lAbdera                  =civ.getTile(61,27,0)
object.lHecatompylos            =civ.getTile(98,38,0)

-- Locations of cities starting the scenario owned by the Ptolemaic Greeks:

object.lAlexandria              =civ.getTile(69,69,0)
object.lCyrene                  =civ.getTile(52,68,0)
object.lMemphis                 =civ.getTile(72,74,0)
object.lRaphia                  =civ.getTile(77,67,0)
object.lHeliopolis              =civ.getTile(73,71,0)

-- Locations of cities starting the scenario owned by the Seleucid Greeks:

object.lAntioch                 =civ.getTile(78,46,0)
object.lMiletus                 =civ.getTile(67,39,0)
object.lSeleucia                =civ.getTile(88,52,0)
object.lDamascus                =civ.getTile(82,54,0)
object.lNisibis                 =civ.getTile(84,36,0)

-- Locations of cities starting the scenario owned by the Ind. Greeks and Allies:

object.lSyracuse                =civ.getTile(44,56,0)
object.lMassilia                =civ.getTile(31,17,0)
object.lPergamum                =civ.getTile(65,33,0)
object.lRhodes                  =civ.getTile(68,46,0)
object.lTaras                   =civ.getTile(52,44,0)
object.lDelphi                  =civ.getTile(57,43,0)

-- Locations of cities starting the scenario owned by the Celts:

object.lLaTene                  =civ.getTile(35,1,0)
object.lSparta                  =civ.getTile(60,50,0)
object.lGalatia                 =civ.getTile(71,31,0)
object.lBraunsberg              =civ.getTile(55,13,0)
object.lMilan                   =civ.getTile(38,12,0)
object.lNumantia                =civ.getTile(11,27,0)

-- Cities
-- recommended key prefix 'c'
-- It is not recommended to put cities into this list if the city
-- can be destroyed. This list returns an error if 'nil' is the value
-- associated with the key (see bottom of file), so that could cause
-- a problem if a city in this list is destroyed.  Also, if another
-- city is founded, the ID number of the city might get reused, causing
-- more confusion.  An alternate way to reference a city is by using
-- object.lRome.city when you actually need the city (and suitably guarding
-- against nil values)

--Find these by entering "for city in civ.iterateCities() do print(city.id, city.name) end" in the console

-- All the cities existing when you made generated this template are listed here.
-- If you wish to use these objects, change the line if false then below to if true then
-- It is your job to eliminate any cities that could be destroyed from this list if you use it
-- If you are not sure, it is recommended to reference cities from their locations instead
--

if false then

--Cities starting the scenario owned by the Barbarians:


--Cities starting the scenario owned by the Romans:

object.cRome                    =civ.getTile(40,28,0).city
object.cNeapolis                =civ.getTile(45,37,0).city
object.cHeraclea                =civ.getTile(49,43,0).city
object.cSena                    =civ.getTile(42,22,0).city
object.cPisae                   =civ.getTile(38,20,0).city
object.cTarracina               =civ.getTile(41,33,0).city

--Cities starting the scenario owned by the Carthaginians:

object.cCarthage                =civ.getTile(36,62,0).city
object.cLilybaeum               =civ.getTile(41,53,0).city
object.cGades                   =civ.getTile(3,57,0).city
object.cCaralis                 =civ.getTile(36,44,0).city
object.cLeptis                  =civ.getTile(40,72,0).city
object.cHippoRegius             =civ.getTile(31,61,0).city

--Cities starting the scenario owned by the Macedonian Greeks:

object.cPella                   =civ.getTile(57,31,0).city
object.cAthens                  =civ.getTile(62,44,0).city
object.cDemetrias               =civ.getTile(59,37,0).city
object.cAbdera                  =civ.getTile(61,27,0).city
object.cHecatompylos            =civ.getTile(98,38,0).city

--Cities starting the scenario owned by the Ptolemaic Greeks:

object.cAlexandria              =civ.getTile(69,69,0).city
object.cCyrene                  =civ.getTile(52,68,0).city
object.cMemphis                 =civ.getTile(72,74,0).city
object.cRaphia                  =civ.getTile(77,67,0).city
object.cHeliopolis              =civ.getTile(73,71,0).city

--Cities starting the scenario owned by the Seleucid Greeks:

object.cAntioch                 =civ.getTile(78,46,0).city
object.cMiletus                 =civ.getTile(67,39,0).city
object.cSeleucia                =civ.getTile(88,52,0).city
object.cDamascus                =civ.getTile(82,54,0).city
object.cNisibis                 =civ.getTile(84,36,0).city

--Cities starting the scenario owned by the Ind. Greeks and Allies:

object.cSyracuse                =civ.getTile(44,56,0).city
object.cMassilia                =civ.getTile(31,17,0).city
object.cPergamum                =civ.getTile(65,33,0).city
object.cRhodes                  =civ.getTile(68,46,0).city
object.cTaras                   =civ.getTile(52,44,0).city
object.cDelphi                  =civ.getTile(57,43,0).city

--Cities starting the scenario owned by the Celts:

object.cLaTene                  =civ.getTile(35,1,0).city
object.cSparta                  =civ.getTile(60,50,0).city
object.cGalatia                 =civ.getTile(71,31,0).city
object.cBraunsberg              =civ.getTile(55,13,0).city
object.cMilan                   =civ.getTile(38,12,0).city
object.cNumantia                =civ.getTile(11,27,0).city

end

-- Unit Types
-- recommended key prefix 'u'

object.uSettlers                = civ.getUnitType(0) --[[@as unitTypeObject]]
object.uEngineers               = civ.getUnitType(1) --[[@as unitTypeObject]]   --Engineers
object.uWarriors                = civ.getUnitType(2) --[[@as unitTypeObject]]
object.uPhalanx                 = civ.getUnitType(3) --[[@as unitTypeObject]]
object.uArchers                 = civ.getUnitType(4) --[[@as unitTypeObject]]
object.uLegion                  = civ.getUnitType(5) --[[@as unitTypeObject]]
object.uPikemen                 = civ.getUnitType(6) --[[@as unitTypeObject]]
object.uMusketeers              = civ.getUnitType(7) --[[@as unitTypeObject]]
object.uFanatics                = civ.getUnitType(8) --[[@as unitTypeObject]]
object.uPartisans               = civ.getUnitType(9) --[[@as unitTypeObject]]
object.uAlpineTroops            = civ.getUnitType(10) --[[@as unitTypeObject]]
object.uRiflemen                = civ.getUnitType(11) --[[@as unitTypeObject]]
object.uMarines                 = civ.getUnitType(12) --[[@as unitTypeObject]]
object.uParatroopers            = civ.getUnitType(13) --[[@as unitTypeObject]]
object.uMechInf                 = civ.getUnitType(14) --[[@as unitTypeObject]]
object.uHorsemen                = civ.getUnitType(15) --[[@as unitTypeObject]]
object.uChariot                 = civ.getUnitType(16) --[[@as unitTypeObject]]
object.uElephant                = civ.getUnitType(17) --[[@as unitTypeObject]]
object.uCrusaders               = civ.getUnitType(18) --[[@as unitTypeObject]]
object.uKnights                 = civ.getUnitType(19) --[[@as unitTypeObject]]
object.uDragoons                = civ.getUnitType(20) --[[@as unitTypeObject]]
object.uCavalry                 = civ.getUnitType(21) --[[@as unitTypeObject]]
object.uArmor                   = civ.getUnitType(22) --[[@as unitTypeObject]]
object.uCatapult                = civ.getUnitType(23) --[[@as unitTypeObject]]
object.uCannon                  = civ.getUnitType(24) --[[@as unitTypeObject]]
object.uArtillery               = civ.getUnitType(25) --[[@as unitTypeObject]]
object.uHowitzer                = civ.getUnitType(26) --[[@as unitTypeObject]]
object.uFighter                 = civ.getUnitType(27) --[[@as unitTypeObject]]
object.uBomber                  = civ.getUnitType(28) --[[@as unitTypeObject]]
object.uHelicopter              = civ.getUnitType(29) --[[@as unitTypeObject]]
object.uStlthFtr                = civ.getUnitType(30) --[[@as unitTypeObject]]
object.uStlthBmbr               = civ.getUnitType(31) --[[@as unitTypeObject]]
object.uTrireme                 = civ.getUnitType(32) --[[@as unitTypeObject]]
object.uCaravel                 = civ.getUnitType(33) --[[@as unitTypeObject]]
object.uGalleon                 = civ.getUnitType(34) --[[@as unitTypeObject]]
object.uFrigate                 = civ.getUnitType(35) --[[@as unitTypeObject]]
object.uIronclad                = civ.getUnitType(36) --[[@as unitTypeObject]]
object.uDestroyer               = civ.getUnitType(37) --[[@as unitTypeObject]]
object.uCruiser                 = civ.getUnitType(38) --[[@as unitTypeObject]]
object.uAegisCruiser            = civ.getUnitType(39) --[[@as unitTypeObject]]
object.uBattleship              = civ.getUnitType(40) --[[@as unitTypeObject]]
object.uSubmarine               = civ.getUnitType(41) --[[@as unitTypeObject]]
object.uCarrier                 = civ.getUnitType(42) --[[@as unitTypeObject]]
object.uTransport               = civ.getUnitType(43) --[[@as unitTypeObject]]
object.uCruiseMsl               = civ.getUnitType(44) --[[@as unitTypeObject]]
object.uNuclearMsl              = civ.getUnitType(45) --[[@as unitTypeObject]]   --Nuclear Msl
object.uDiplomat                = civ.getUnitType(46) --[[@as unitTypeObject]]
object.uSpy                     = civ.getUnitType(47) --[[@as unitTypeObject]]   --Spy
object.uCaravan                 = civ.getUnitType(48) --[[@as unitTypeObject]]
object.uFreight                 = civ.getUnitType(49) --[[@as unitTypeObject]]   --Freight
object.uExplorer                = civ.getUnitType(50) --[[@as unitTypeObject]]
object.uModernArmor             = civ.getUnitType(51) --[[@as unitTypeObject]]
object.uFlakCanon               = civ.getUnitType(52) --[[@as unitTypeObject]]
object.uExtraAir                = civ.getUnitType(53) --[[@as unitTypeObject]]
object.unotuseda                = civ.getUnitType(54) --[[@as unitTypeObject]]
object.unotusedb                = civ.getUnitType(55) --[[@as unitTypeObject]]
object.unotusedc                = civ.getUnitType(56) --[[@as unitTypeObject]]
object.unotusedd                = civ.getUnitType(57) --[[@as unitTypeObject]]
object.unotusede                = civ.getUnitType(58) --[[@as unitTypeObject]]
object.unotusedf                = civ.getUnitType(59) --[[@as unitTypeObject]]
object.unotusedg                = civ.getUnitType(60) --[[@as unitTypeObject]]
object.unotusedh                = civ.getUnitType(61) --[[@as unitTypeObject]]
object.unotusedi                = civ.getUnitType(62) --[[@as unitTypeObject]]
object.unotusedj                = civ.getUnitType(63) --[[@as unitTypeObject]]
object.unotusedk                = civ.getUnitType(64) --[[@as unitTypeObject]]
object.unotusedl                = civ.getUnitType(65) --[[@as unitTypeObject]]
object.unotusedm                = civ.getUnitType(66) --[[@as unitTypeObject]]
object.unotusedn                = civ.getUnitType(67) --[[@as unitTypeObject]]
object.unotusedo                = civ.getUnitType(68) --[[@as unitTypeObject]]
object.unotusedp                = civ.getUnitType(69) --[[@as unitTypeObject]]
object.unotusedq                = civ.getUnitType(70) --[[@as unitTypeObject]]
object.unotusedr                = civ.getUnitType(71) --[[@as unitTypeObject]]
object.unotuseds                = civ.getUnitType(72) --[[@as unitTypeObject]]
object.unotusedt                = civ.getUnitType(73) --[[@as unitTypeObject]]
object.unotusedu                = civ.getUnitType(74) --[[@as unitTypeObject]]
object.unotusedv                = civ.getUnitType(75) --[[@as unitTypeObject]]
object.unotusedw                = civ.getUnitType(76) --[[@as unitTypeObject]]
object.unotusedx                = civ.getUnitType(77) --[[@as unitTypeObject]]
object.unotusedy                = civ.getUnitType(78) --[[@as unitTypeObject]]
object.unotusedz                = civ.getUnitType(79) --[[@as unitTypeObject]]

-- City Improvements
-- recommended key prefix 'i'
--          

object.iNothing                 = civ.getImprovement(0) --[[@as improvementObject]]
object.iPalace                  = civ.getImprovement(1) --[[@as improvementObject]]
object.iBarracks                = civ.getImprovement(2) --[[@as improvementObject]]
object.iGranary                 = civ.getImprovement(3) --[[@as improvementObject]]
object.iTemple                  = civ.getImprovement(4) --[[@as improvementObject]]
object.iMarketPlace             = civ.getImprovement(5) --[[@as improvementObject]]
object.iLibrary                 = civ.getImprovement(6) --[[@as improvementObject]]
object.iCourthouse              = civ.getImprovement(7) --[[@as improvementObject]]
object.iCityWalls               = civ.getImprovement(8) --[[@as improvementObject]]
object.iAqueduct                = civ.getImprovement(9) --[[@as improvementObject]]
object.iBank                    = civ.getImprovement(10) --[[@as improvementObject]]
object.iCathedral               = civ.getImprovement(11) --[[@as improvementObject]]
object.iUniversity              = civ.getImprovement(12) --[[@as improvementObject]]
object.iMassTransit             = civ.getImprovement(13) --[[@as improvementObject]]
object.iColosseum               = civ.getImprovement(14) --[[@as improvementObject]]
object.iFactory                 = civ.getImprovement(15) --[[@as improvementObject]]
object.iManufacturingPlant      = civ.getImprovement(16) --[[@as improvementObject]]
object.iSDIDefense              = civ.getImprovement(17) --[[@as improvementObject]]
object.iRecyclingCenter         = civ.getImprovement(18) --[[@as improvementObject]]
object.iPowerPlant              = civ.getImprovement(19) --[[@as improvementObject]]
object.iHydroPlant              = civ.getImprovement(20) --[[@as improvementObject]]
object.iNuclearPlant            = civ.getImprovement(21) --[[@as improvementObject]]
object.iStockExchange           = civ.getImprovement(22) --[[@as improvementObject]]
object.iSewerSystem             = civ.getImprovement(23) --[[@as improvementObject]]
object.iSupermarket             = civ.getImprovement(24) --[[@as improvementObject]]
object.iSuperhighways           = civ.getImprovement(25) --[[@as improvementObject]]
object.iResearchLab             = civ.getImprovement(26) --[[@as improvementObject]]
object.iSAMBattery              = civ.getImprovement(27) --[[@as improvementObject]]
object.iCoastalFortress         = civ.getImprovement(28) --[[@as improvementObject]]
object.iSolarPlant              = civ.getImprovement(29) --[[@as improvementObject]]
object.iHarbor                  = civ.getImprovement(30) --[[@as improvementObject]]
object.iOffshorePlatform        = civ.getImprovement(31) --[[@as improvementObject]]
object.iAirport                 = civ.getImprovement(32) --[[@as improvementObject]]
object.iPoliceStation           = civ.getImprovement(33) --[[@as improvementObject]]
object.iPortFacility            = civ.getImprovement(34) --[[@as improvementObject]]
object.iTransporter             = civ.getImprovement(35) --[[@as improvementObject]]

-- Players (Tribes)
-- recommended key prefix 'p'

object.pBarbarians              = civ.getTribe(0) --[[@as tribeObject]]
object.pRomans                  = civ.getTribe(1) --[[@as tribeObject]]
object.pCarthaginians           = civ.getTribe(2) --[[@as tribeObject]]
object.pMacedonianGreeks        = civ.getTribe(3) --[[@as tribeObject]]
object.pPtolemaicGreeks         = civ.getTribe(4) --[[@as tribeObject]]
object.pSeleucidGreeks          = civ.getTribe(5) --[[@as tribeObject]]
object.pIndGreeksandAllies      = civ.getTribe(6) --[[@as tribeObject]]
object.pCelts                   = civ.getTribe(7) --[[@as tribeObject]]

-- Wonders
-- recommended key prefix 'w'

object.wPyramids                = civ.getWonder(0) --[[@as wonderObject]]
object.wHangingGardens          = civ.getWonder(1) --[[@as wonderObject]]
object.wColossus                = civ.getWonder(2) --[[@as wonderObject]]
object.wLighthouse              = civ.getWonder(3) --[[@as wonderObject]]
object.wGreatLibrary            = civ.getWonder(4) --[[@as wonderObject]]
object.wOracle                  = civ.getWonder(5) --[[@as wonderObject]]
object.wGreatWall               = civ.getWonder(6) --[[@as wonderObject]]
object.wSunTzusWarAcademy       = civ.getWonder(7) --[[@as wonderObject]]
object.wKingRichardsCrusade     = civ.getWonder(8) --[[@as wonderObject]]
object.wMarcoPolosEmbassy       = civ.getWonder(9) --[[@as wonderObject]]
object.wMichelangelosChapel     = civ.getWonder(10) --[[@as wonderObject]]
object.wCopernicusObservatory   = civ.getWonder(11) --[[@as wonderObject]]
object.wMagellansExpedition     = civ.getWonder(12) --[[@as wonderObject]]
object.wShakespearesTheater     = civ.getWonder(13) --[[@as wonderObject]]
object.wLeonardosWorkshop       = civ.getWonder(14) --[[@as wonderObject]]
object.wJSBachsCathedral        = civ.getWonder(15) --[[@as wonderObject]]
object.wIsaacNewtonsCollege     = civ.getWonder(16) --[[@as wonderObject]]
object.wAdamSmithsTradingCo     = civ.getWonder(17) --[[@as wonderObject]]
object.wDarwinsVoyage           = civ.getWonder(18) --[[@as wonderObject]]
object.wStatueofLiberty         = civ.getWonder(19) --[[@as wonderObject]]
object.wEiffelTower             = civ.getWonder(20) --[[@as wonderObject]]
object.wWomensSuffrage          = civ.getWonder(21) --[[@as wonderObject]]
object.wHooverDam               = civ.getWonder(22) --[[@as wonderObject]]
object.wManhattanProject        = civ.getWonder(23) --[[@as wonderObject]]
object.wUnitedNations           = civ.getWonder(24) --[[@as wonderObject]]
object.wApolloProgram           = civ.getWonder(25) --[[@as wonderObject]]
object.wSETIProgram             = civ.getWonder(26) --[[@as wonderObject]]
object.wCureforCancer           = civ.getWonder(27) --[[@as wonderObject]]

-- Base Terrain
-- recommended prefix 'b'

object.bDesert                  =civ.getBaseTerrain(0,0) --[[@as baseTerrainObject]]  --Drt
object.bPlains                  =civ.getBaseTerrain(0,1) --[[@as baseTerrainObject]]  --Pln
object.bGrassland               =civ.getBaseTerrain(0,2) --[[@as baseTerrainObject]]  --Grs
object.bForest                  =civ.getBaseTerrain(0,3) --[[@as baseTerrainObject]]  --For
object.bHills                   =civ.getBaseTerrain(0,4) --[[@as baseTerrainObject]]  --Hil
object.bMountains               =civ.getBaseTerrain(0,5) --[[@as baseTerrainObject]]  --Mou
object.bTundra                  =civ.getBaseTerrain(0,6) --[[@as baseTerrainObject]]  --Tun
object.bGlacier                 =civ.getBaseTerrain(0,7) --[[@as baseTerrainObject]]  --Gla
object.bSwamp                   =civ.getBaseTerrain(0,8) --[[@as baseTerrainObject]]  --Swa
object.bJungle                  =civ.getBaseTerrain(0,9) --[[@as baseTerrainObject]]  --Jun
object.bOcean                   =civ.getBaseTerrain(0,10) --[[@as baseTerrainObject]]  --Oce
object.bCity                    =civ.getBaseTerrain(0,11) --[[@as baseTerrainObject]]  --Bbb

-- Terrain
-- recommended prefix 't'

object.tDesert                  =civ.getTerrain(0,0,0) --[[@as terrainObject]]
object.tOasis                   =civ.getTerrain(0,0,1) --[[@as terrainObject]] -- Fish Resource
object.tDesertOil               =civ.getTerrain(0,0,2) --[[@as terrainObject]] -- Whale Resource
object.tPlains                  =civ.getTerrain(0,1,0) --[[@as terrainObject]]
object.tBuffalo                 =civ.getTerrain(0,1,1) --[[@as terrainObject]] -- Fish Resource
object.tWheat                   =civ.getTerrain(0,1,2) --[[@as terrainObject]] -- Whale Resource
object.tGrassland               =civ.getTerrain(0,2,0) --[[@as terrainObject]]
object.tForest                  =civ.getTerrain(0,3,0) --[[@as terrainObject]]
object.tPheasant                =civ.getTerrain(0,3,1) --[[@as terrainObject]] -- Fish Resource
object.tSilk                    =civ.getTerrain(0,3,2) --[[@as terrainObject]] -- Whale Resource
object.tHills                   =civ.getTerrain(0,4,0) --[[@as terrainObject]]
object.tCoal                    =civ.getTerrain(0,4,1) --[[@as terrainObject]] -- Fish Resource
object.tWine                    =civ.getTerrain(0,4,2) --[[@as terrainObject]] -- Whale Resource
object.tMountains               =civ.getTerrain(0,5,0) --[[@as terrainObject]]
object.tGold                    =civ.getTerrain(0,5,1) --[[@as terrainObject]] -- Fish Resource
object.tIron                    =civ.getTerrain(0,5,2) --[[@as terrainObject]] -- Whale Resource
object.tTundra                  =civ.getTerrain(0,6,0) --[[@as terrainObject]]
object.tGame                    =civ.getTerrain(0,6,1) --[[@as terrainObject]] -- Fish Resource
object.tFurs                    =civ.getTerrain(0,6,2) --[[@as terrainObject]] -- Whale Resource
object.tGlacier                 =civ.getTerrain(0,7,0) --[[@as terrainObject]]
object.tIvory                   =civ.getTerrain(0,7,1) --[[@as terrainObject]] -- Fish Resource
object.tGlacierOil              =civ.getTerrain(0,7,2) --[[@as terrainObject]] -- Whale Resource
object.tSwamp                   =civ.getTerrain(0,8,0) --[[@as terrainObject]]
object.tPeat                    =civ.getTerrain(0,8,1) --[[@as terrainObject]] -- Fish Resource
object.tSpice                   =civ.getTerrain(0,8,2) --[[@as terrainObject]] -- Whale Resource
object.tJungle                  =civ.getTerrain(0,9,0) --[[@as terrainObject]]
object.tGems                    =civ.getTerrain(0,9,1) --[[@as terrainObject]] -- Fish Resource
object.tFruit                   =civ.getTerrain(0,9,2) --[[@as terrainObject]] -- Whale Resource
object.tOcean                   =civ.getTerrain(0,10,0) --[[@as terrainObject]]
object.tFish                    =civ.getTerrain(0,10,1) --[[@as terrainObject]] -- Fish Resource
object.tWhales                  =civ.getTerrain(0,10,2) --[[@as terrainObject]] -- Whale Resource
object.tCity                    =civ.getTerrain(0,11,0) --[[@as terrainObject]]
object.tMegalopolis             =civ.getTerrain(0,11,1) --[[@as terrainObject]] -- Fish Resource
object.tIndustries              =civ.getTerrain(0,11,2) --[[@as terrainObject]] -- Whale Resource

-- Text
-- You might find it easier to keep much of your events text here
-- Remember, you can place %STRING1, %STRING2, etc. in your text and
-- use text.substitute to insert the actual values in the event, instead
-- of splitting the text into multiple parts
-- recommended prefix 'x'


-- Images
-- For optimal integration with the image functionality of the
-- text module, it is recommended that you load all your
-- images here.
-- recommended prefix `m`
--
text.setImageTable(object,"object")-- The string "object" provides a name of the table for error messages.


-- Flag, Counter and Phrase Definitions
-- Flags, counters, and phrases have to be defined somewhere,
-- and you may find it convenient to define some here.






-- this will give you an if you try to access a key not entered into
-- the object table, which could be helpful for debugging, but it
-- means that no nil value can ever be returned for table object
-- If you need that ability, comment out this line
gen.forbidNilValueAccess(object)

return object
