local unitKilledEvents = {}
local object = require("object")
local text = require("text")
-- This will only run when a unit is killed in combat (i.e. not when an event
-- 'kills' a unit)
-- note that if the aggressor loses, aggressor.location will not work
--
local elephantCampaignCost = 5
local catapultCampaignCost = 4
local twoMoveCampaignCost = 3
local defaultCampaignCost = 1
--local campaignCost = 1
local modernUnits={
    [object.uArmor.id]=true,
    [object.uMechInf.id]=true,
    [object.uHelicopter.id]=true,
    [object.uParatroopers.id]=true,
}
function unitKilledEvents.unitKilledInCombat(loser ,winner ,aggressor,victim,loserLocation,winnerVetStatus,loserVetStatus)
    --loser.owner.money = math.max(loser.owner.money -campaignCost,0)
    --winner.owner.money = math.max(winner.owner.money-campaignCost,0)
    if loser.hitpoints <= 0 then
        for __,unit in pairs({winner,loser}) do
            if unit.type == object.uElephant then
                unit.owner.money = math.max(unit.owner.money-elephantCampaignCost,0)
            elseif unit.type == object.uCatapult then
                unit.owner.money = math.max(unit.owner.money-catapultCampaignCost,0)
            elseif unit.type.move == 2*totpp.movementMultipliers.aggregate then
                unit.owner.money = math.max(unit.owner.money-twoMoveCampaignCost,0)
            else
                unit.owner.money = math.max(unit.owner.money-defaultCampaignCost,0)
            end
        end
    end
    if modernUnits[winner.type.id] and winner.owner.isHuman then
        text.simple("I didn't know the "..winner.owner.name.." used "..winner.type.name..".","Historian")
    end
end


-- This will run any time a unit is killed, either in combat or by events
--
function unitKilledEvents.unitDefeated(loser,winner,aggressor,victim,loserLocation,winnerVetStatus,loserVetStatus)

end

-- this happens whenever a unit 'dies', regardless of combat, as long as it is not replaced
function unitKilledEvents.unitDeath(dyingUnit)

end

-- this happens whenever a unit 'dies', but not through combat (or 'defeat')
function unitKilledEvents.unitDeathOutsideCombat(dyingUnit)

end
-- this happens if a unit is deleted (either through combat death, or by some other event,
-- but not if the unit is disbanded)
-- If the unit isn't being replaced, replacingUnit is nil
function unitKilledEvents.unitDeleted(deletedUnit,replacingUnit)

end

return unitKilledEvents

