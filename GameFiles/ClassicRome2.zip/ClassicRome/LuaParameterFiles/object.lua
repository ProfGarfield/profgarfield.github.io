local flag = require("flag")

local object = {}

-- Civilization Advances
-- recommended key prefix 'a'

object.aAdvancedFlight          = civ.getTech(0)
object.aAlphabet                = civ.getTech(1)
object.aAmphibiousWarfare       = civ.getTech(2)
object.aAstronomy               = civ.getTech(3)
object.aAtomicTheory            = civ.getTech(4)
object.aAutomobile              = civ.getTech(5)   --Automobile
object.aBanking                 = civ.getTech(6)
object.aBridgeBuilding          = civ.getTech(7)   --Bridge Building
object.aBronzeWorking           = civ.getTech(8)
object.aCeremonialBurial        = civ.getTech(9)
object.aChemistry               = civ.getTech(10)
object.aChivalry                = civ.getTech(11)
object.aCodeofLaws              = civ.getTech(12)
object.aCombinedArms            = civ.getTech(13)
object.aCombustion              = civ.getTech(14)
object.aCommunism               = civ.getTech(15)
object.aComputers               = civ.getTech(16)
object.aConscription            = civ.getTech(17)
object.aConstruction            = civ.getTech(18)
object.aTheCorporation          = civ.getTech(19)
object.aCurrency                = civ.getTech(20)
object.aDemocracy               = civ.getTech(21)
object.aEconomics               = civ.getTech(22)
object.aElectricity             = civ.getTech(23)
object.aElectronics             = civ.getTech(24)
object.aEngineering             = civ.getTech(25)
object.aEnvironmentalism        = civ.getTech(26)
object.aEspionage               = civ.getTech(27)
object.aExplosives              = civ.getTech(28)
object.aFeudalism               = civ.getTech(29)
object.aFlight                  = civ.getTech(30)
object.aFundamentalism          = civ.getTech(31)
object.aFusionPower             = civ.getTech(32)
object.aGeneticEngineering      = civ.getTech(33)
object.aGuerrillaWarfare        = civ.getTech(34)
object.aGunpowder               = civ.getTech(35)
object.aHorsebackRiding         = civ.getTech(36)
object.aIndustrialization       = civ.getTech(37)
object.aInvention               = civ.getTech(38)
object.aIronWorking             = civ.getTech(39)
object.aLaborUnion              = civ.getTech(40)
object.aTheLaser                = civ.getTech(41)
object.aLeadership              = civ.getTech(42)
object.aLiteracy                = civ.getTech(43)
object.aMachineTools            = civ.getTech(44)
object.aMagnetism               = civ.getTech(45)
object.aMapMaking               = civ.getTech(46)
object.aMasonry                 = civ.getTech(47)
object.aMassProduction          = civ.getTech(48)
object.aMathematics             = civ.getTech(49)
object.aMedicine                = civ.getTech(50)
object.aMetallurgy              = civ.getTech(51)
object.aMiniaturization         = civ.getTech(52)
object.aMobileWarfare           = civ.getTech(53)
object.aMonarchy                = civ.getTech(54)
object.aMonotheism              = civ.getTech(55)
object.aMysticism               = civ.getTech(56)
object.aNavigation              = civ.getTech(57)
object.aNuclearFission          = civ.getTech(58)
object.aNuclearPower            = civ.getTech(59)
object.aPhilosophy              = civ.getTech(60)
object.aPhysics                 = civ.getTech(61)
object.aPlastics                = civ.getTech(62)
object.aPlumbing                = civ.getTech(63)
object.aPolytheism              = civ.getTech(64)
object.aPottery                 = civ.getTech(65)
object.aRadio                   = civ.getTech(66)
object.aRailroad                = civ.getTech(67)
object.aRecycling               = civ.getTech(68)
object.aRefining                = civ.getTech(69)
object.aRefrigeration           = civ.getTech(70)
object.aTheRepublic             = civ.getTech(71)
object.aRobotics                = civ.getTech(72)
object.aRocketry                = civ.getTech(73)
object.aSanitation              = civ.getTech(74)
object.aSeafaring               = civ.getTech(75)
object.aSpaceFlight             = civ.getTech(76)
object.aStealth                 = civ.getTech(77)
object.aSteamEngine             = civ.getTech(78)
object.aSteel                   = civ.getTech(79)
object.aSuperconductor          = civ.getTech(80)
object.aTactics                 = civ.getTech(81)
object.aTheology                = civ.getTech(82)
object.aTheoryofGravity         = civ.getTech(83)
object.aTrade                   = civ.getTech(84)
object.aUniversity              = civ.getTech(85)
object.aWarriorCode             = civ.getTech(86)
object.aTheWheel                = civ.getTech(87)
object.aWriting                 = civ.getTech(88)
object.aFutureTechnology        = civ.getTech(89)
object.aUserDefTechA            = civ.getTech(90)
object.aUserDefTechB            = civ.getTech(91)
object.aUserDefTechC            = civ.getTech(92)
object.aExtraAdvance1           = civ.getTech(93)
object.aExtraAdvance2           = civ.getTech(94)
object.aExtraAdvance3           = civ.getTech(95)
object.aExtraAdvance4           = civ.getTech(96)
object.aExtraAdvance5           = civ.getTech(97)
object.aExtraAdvance6           = civ.getTech(98)
object.aExtraAdvance7           = civ.getTech(99)

-- Map Locations (tiles/squares)
-- recommended key prefix 'l'


-- Locations of cities starting the scenario owned by the Barbarians:


-- Locations of cities starting the scenario owned by the Romans:

object.lRome                    =civ.getTile(40,28,0)
object.lNeapolis                =civ.getTile(45,37,0)
object.lHeraclea                =civ.getTile(49,43,0)
object.lSena                    =civ.getTile(42,22,0)
object.lPisae                   =civ.getTile(38,20,0)
object.lTarracina               =civ.getTile(41,33,0)

-- Locations of cities starting the scenario owned by the Carthaginians:

object.lCarthage                =civ.getTile(36,62,0)
object.lLilybaeum               =civ.getTile(41,53,0)
object.lGades                   =civ.getTile(3,57,0)
object.lCaralis                 =civ.getTile(36,44,0)
object.lLeptis                  =civ.getTile(40,72,0)
object.lHippoRegius             =civ.getTile(31,61,0)

-- Locations of cities starting the scenario owned by the Macedonian Greeks:

object.lPella                   =civ.getTile(57,31,0)
object.lAthens                  =civ.getTile(62,44,0)
object.lDemetrias               =civ.getTile(59,37,0)
object.lAbdera                  =civ.getTile(61,27,0)
object.lHecatompylos            =civ.getTile(98,38,0)

-- Locations of cities starting the scenario owned by the Ptolemaic Greeks:

object.lAlexandria              =civ.getTile(69,69,0)
object.lCyrene                  =civ.getTile(52,68,0)
object.lMemphis                 =civ.getTile(72,74,0)
object.lRaphia                  =civ.getTile(77,67,0)
object.lHeliopolis              =civ.getTile(73,71,0)

-- Locations of cities starting the scenario owned by the Seleucid Greeks:

object.lAntioch                 =civ.getTile(78,46,0)
object.lMiletus                 =civ.getTile(67,39,0)
object.lSeleucia                =civ.getTile(88,52,0)
object.lDamascus                =civ.getTile(82,54,0)
object.lNisibis                 =civ.getTile(84,36,0)

-- Locations of cities starting the scenario owned by the Ind. Greeks and Allies:

object.lSyracuse                =civ.getTile(44,56,0)
object.lMassilia                =civ.getTile(31,17,0)
object.lPergamum                =civ.getTile(65,33,0)
object.lRhodes                  =civ.getTile(68,46,0)
object.lTaras                   =civ.getTile(52,44,0)
object.lDelphi                  =civ.getTile(57,43,0)

-- Locations of cities starting the scenario owned by the Celts:

object.lLaTene                  =civ.getTile(35,1,0)
object.lSparta                  =civ.getTile(60,50,0)
object.lGalatia                 =civ.getTile(71,31,0)
object.lBraunsberg              =civ.getTile(55,13,0)
object.lMilan                   =civ.getTile(38,12,0)
object.lNumantia                =civ.getTile(11,27,0)

-- Cities
-- recommended key prefix 'c'
-- It is not recommended to put cities into this list if the city
-- can be destroyed. This list returns an error if 'nil' is the value
-- associated with the key (see bottom of file), so that could cause
-- a problem if a city in this list is destroyed.  Also, if another
-- city is founded, the ID number of the city might get reused, causing
-- more confusion.  An alternate way to reference a city is by using
-- object.lRome.city when you actually need the city (and suitably guarding
-- against nil values)

--Find these by entering "for city in civ.iterateCities() do print(city.id, city.name) end" in the console

-- All the cities existing when you made generated this template are listed here.
-- If you wish to use these objects, change the line if false then below to if true then
-- It is your job to eliminate any cities that could be destroyed from this list if you use it
-- If you are not sure, it is recommended to reference cities from their locations instead
--

if false then

--Cities starting the scenario owned by the Barbarians:


--Cities starting the scenario owned by the Romans:

object.cRome                    =civ.getTile(40,28,0).city
object.cNeapolis                =civ.getTile(45,37,0).city
object.cHeraclea                =civ.getTile(49,43,0).city
object.cSena                    =civ.getTile(42,22,0).city
object.cPisae                   =civ.getTile(38,20,0).city
object.cTarracina               =civ.getTile(41,33,0).city

--Cities starting the scenario owned by the Carthaginians:

object.cCarthage                =civ.getTile(36,62,0).city
object.cLilybaeum               =civ.getTile(41,53,0).city
object.cGades                   =civ.getTile(3,57,0).city
object.cCaralis                 =civ.getTile(36,44,0).city
object.cLeptis                  =civ.getTile(40,72,0).city
object.cHippoRegius             =civ.getTile(31,61,0).city

--Cities starting the scenario owned by the Macedonian Greeks:

object.cPella                   =civ.getTile(57,31,0).city
object.cAthens                  =civ.getTile(62,44,0).city
object.cDemetrias               =civ.getTile(59,37,0).city
object.cAbdera                  =civ.getTile(61,27,0).city
object.cHecatompylos            =civ.getTile(98,38,0).city

--Cities starting the scenario owned by the Ptolemaic Greeks:

object.cAlexandria              =civ.getTile(69,69,0).city
object.cCyrene                  =civ.getTile(52,68,0).city
object.cMemphis                 =civ.getTile(72,74,0).city
object.cRaphia                  =civ.getTile(77,67,0).city
object.cHeliopolis              =civ.getTile(73,71,0).city

--Cities starting the scenario owned by the Seleucid Greeks:

object.cAntioch                 =civ.getTile(78,46,0).city
object.cMiletus                 =civ.getTile(67,39,0).city
object.cSeleucia                =civ.getTile(88,52,0).city
object.cDamascus                =civ.getTile(82,54,0).city
object.cNisibis                 =civ.getTile(84,36,0).city

--Cities starting the scenario owned by the Ind. Greeks and Allies:

object.cSyracuse                =civ.getTile(44,56,0).city
object.cMassilia                =civ.getTile(31,17,0).city
object.cPergamum                =civ.getTile(65,33,0).city
object.cRhodes                  =civ.getTile(68,46,0).city
object.cTaras                   =civ.getTile(52,44,0).city
object.cDelphi                  =civ.getTile(57,43,0).city

--Cities starting the scenario owned by the Celts:

object.cLaTene                  =civ.getTile(35,1,0).city
object.cSparta                  =civ.getTile(60,50,0).city
object.cGalatia                 =civ.getTile(71,31,0).city
object.cBraunsberg              =civ.getTile(55,13,0).city
object.cMilan                   =civ.getTile(38,12,0).city
object.cNumantia                =civ.getTile(11,27,0).city

end

-- Unit Types
-- recommended key prefix 'u'

object.uSettlers                = civ.getUnitType(0)
object.uEngineers               = civ.getUnitType(1)   --Engineers
object.uWarriors                = civ.getUnitType(2)
object.uPhalanx                 = civ.getUnitType(3)
object.uArchers                 = civ.getUnitType(4)
object.uLegion                  = civ.getUnitType(5)
object.uPikemen                 = civ.getUnitType(6)
object.uMusketeers              = civ.getUnitType(7)
object.uFanatics                = civ.getUnitType(8)
object.uPartisans               = civ.getUnitType(9)
object.uAlpineTroops            = civ.getUnitType(10)
object.uRiflemen                = civ.getUnitType(11)
object.uMarines                 = civ.getUnitType(12)
object.uParatroopers            = civ.getUnitType(13)
object.uMechInf                 = civ.getUnitType(14)
object.uHorsemen                = civ.getUnitType(15)
object.uChariot                 = civ.getUnitType(16)
object.uElephant                = civ.getUnitType(17)
object.uCrusaders               = civ.getUnitType(18)
object.uKnights                 = civ.getUnitType(19)
object.uDragoons                = civ.getUnitType(20)
object.uCavalry                 = civ.getUnitType(21)
object.uArmor                   = civ.getUnitType(22)
object.uCatapult                = civ.getUnitType(23)
object.uCannon                  = civ.getUnitType(24)
object.uArtillery               = civ.getUnitType(25)
object.uHowitzer                = civ.getUnitType(26)
object.uFighter                 = civ.getUnitType(27)
object.uBomber                  = civ.getUnitType(28)
object.uHelicopter              = civ.getUnitType(29)
object.uStlthFtr                = civ.getUnitType(30)
object.uStlthBmbr               = civ.getUnitType(31)
object.uTrireme                 = civ.getUnitType(32)
object.uCaravel                 = civ.getUnitType(33)
object.uGalleon                 = civ.getUnitType(34)
object.uFrigate                 = civ.getUnitType(35)
object.uIronclad                = civ.getUnitType(36)
object.uDestroyer               = civ.getUnitType(37)
object.uCruiser                 = civ.getUnitType(38)
object.uAEGISCruiser            = civ.getUnitType(39)
object.uBattleship              = civ.getUnitType(40)
object.uSubmarine               = civ.getUnitType(41)
object.uCarrier                 = civ.getUnitType(42)
object.uTransport               = civ.getUnitType(43)
object.uCruiseMsl               = civ.getUnitType(44)
object.uNuclearMsl              = civ.getUnitType(45)   --Nuclear Msl
object.uDiplomat                = civ.getUnitType(46)
object.uSpy                     = civ.getUnitType(47)   --Spy
object.uCaravan                 = civ.getUnitType(48)
object.uFreight                 = civ.getUnitType(49)   --Freight
object.uExplorer                = civ.getUnitType(50)
object.uExtraLand               = civ.getUnitType(51)
object.uExtraShip               = civ.getUnitType(52)
object.uExtraAir                = civ.getUnitType(53)
object.uTestUnit1               = civ.getUnitType(54)
object.uTestUnit2               = civ.getUnitType(55)
object.uTestUnit3               = civ.getUnitType(56)
object.uTestUnit4               = civ.getUnitType(57)
object.uTestUnit5               = civ.getUnitType(58)
object.uTestUnit6               = civ.getUnitType(59)
object.uTestUnit7               = civ.getUnitType(60)
object.uTestUnit8               = civ.getUnitType(61)
object.uUnit63                  = civ.getUnitType(62)
object.uUnit64                  = civ.getUnitType(63)
object.uUnit65                  = civ.getUnitType(64)
object.uUnit66                  = civ.getUnitType(65)
object.uUnit67                  = civ.getUnitType(66)
object.uUnit68                  = civ.getUnitType(67)
object.uUnit69                  = civ.getUnitType(68)
object.uUnit70                  = civ.getUnitType(69)
object.uUnit71                  = civ.getUnitType(70)
object.uUnit72                  = civ.getUnitType(71)
object.uUnit73                  = civ.getUnitType(72)
object.uUnit74                  = civ.getUnitType(73)
object.uUnit75                  = civ.getUnitType(74)
object.uUnit76                  = civ.getUnitType(75)
object.uUnit77                  = civ.getUnitType(76)
object.uUnit78                  = civ.getUnitType(77)
object.uUnit79                  = civ.getUnitType(78)
object.uUnit80                  = civ.getUnitType(79)

-- City Improvements
-- recommended key prefix 'i'
--          

object.iNothing                 = civ.getImprovement(0)
object.iPalace                  = civ.getImprovement(1)
object.iBarracks                = civ.getImprovement(2)
object.iGranary                 = civ.getImprovement(3)
object.iTemple                  = civ.getImprovement(4)
object.iMarketPlace             = civ.getImprovement(5)
object.iLibrary                 = civ.getImprovement(6)
object.iCourthouse              = civ.getImprovement(7)
object.iCityWalls               = civ.getImprovement(8)
object.iAqueduct                = civ.getImprovement(9)
object.iBank                    = civ.getImprovement(10)
object.iCathedral               = civ.getImprovement(11)
object.iUniversity              = civ.getImprovement(12)
object.iMassTransit             = civ.getImprovement(13)
object.iColosseum               = civ.getImprovement(14)
object.iFactory                 = civ.getImprovement(15)
object.iManufacturingPlant      = civ.getImprovement(16)
object.iSDIDefense              = civ.getImprovement(17)
object.iRecyclingCenter         = civ.getImprovement(18)
object.iPowerPlant              = civ.getImprovement(19)
object.iHydroPlant              = civ.getImprovement(20)
object.iNuclearPlant            = civ.getImprovement(21)
object.iStockExchange           = civ.getImprovement(22)
object.iSewerSystem             = civ.getImprovement(23)
object.iSupermarket             = civ.getImprovement(24)
object.iSuperhighways           = civ.getImprovement(25)
object.iResearchLab             = civ.getImprovement(26)
object.iSAMMissileBattery       = civ.getImprovement(27)
object.iCoastalFortress         = civ.getImprovement(28)
object.iSolarPlant              = civ.getImprovement(29)
object.iHarbor                  = civ.getImprovement(30)
object.iOffshorePlatform        = civ.getImprovement(31)
object.iAirport                 = civ.getImprovement(32)
object.iPoliceStation           = civ.getImprovement(33)
object.iPortFacility            = civ.getImprovement(34)
object.iTransporter             = civ.getImprovement(35)

-- Players (Tribes)
-- recommended key prefix 'p'

object.pBarbarians              = civ.getTribe(0)
object.pRomans                  = civ.getTribe(1)
object.pCarthaginians           = civ.getTribe(2)
object.pMacedonianGreeks        = civ.getTribe(3)
object.pPtolemaicGreeks         = civ.getTribe(4)
object.pSeleucidGreeks          = civ.getTribe(5)
object.pIndGreeksandAllies      = civ.getTribe(6)
object.pCelts                   = civ.getTribe(7)

-- Wonders
-- recommended key prefix 'w'

object.wPyramids                = civ.getWonder(0)
object.wHangingGardens          = civ.getWonder(1)
object.wColossus                = civ.getWonder(2)
object.wLighthouse              = civ.getWonder(3)
object.wGreatLibrary            = civ.getWonder(4)
object.wOracle                  = civ.getWonder(5)
object.wGreatWall               = civ.getWonder(6)
object.wSunTzusWarAcademy       = civ.getWonder(7)
object.wKingRichardsCrusade     = civ.getWonder(8)
object.wMarcoPolosEmbassy       = civ.getWonder(9)
object.wMichelangelosChapel     = civ.getWonder(10)
object.wCopernicusObservatory   = civ.getWonder(11)
object.wMagellansExpedition     = civ.getWonder(12)
object.wShakespearesTheatre     = civ.getWonder(13)
object.wLeonardosWorkshop       = civ.getWonder(14)
object.wJSBachsCathedral        = civ.getWonder(15)
object.wIsaacNewtonsCollege     = civ.getWonder(16)
object.wAdamSmithsTradingCo     = civ.getWonder(17)
object.wDarwinsVoyage           = civ.getWonder(18)
object.wStatueofLiberty         = civ.getWonder(19)
object.wEiffelTower             = civ.getWonder(20)
object.wWomensSuffrage          = civ.getWonder(21)
object.wHooverDam               = civ.getWonder(22)
object.wManhattanProject        = civ.getWonder(23)
object.wUnitedNations           = civ.getWonder(24)
object.wApolloProgram           = civ.getWonder(25)
object.wSETIProgram             = civ.getWonder(26)
object.wCureforCancer           = civ.getWonder(27)

-- Base Terrain
-- recommended prefix 'b'

object.bDesert                  =civ.getBaseTerrain(0,0)  --Drt
object.bPlains                  =civ.getBaseTerrain(0,1)  --Pln
object.bGrassland               =civ.getBaseTerrain(0,2)  --Grs
object.bForest                  =civ.getBaseTerrain(0,3)  --For
object.bHills                   =civ.getBaseTerrain(0,4)  --Hil
object.bMountains               =civ.getBaseTerrain(0,5)  --Mou
object.bTundra                  =civ.getBaseTerrain(0,6)  --Tun
object.bGlacier                 =civ.getBaseTerrain(0,7)  --Gla
object.bSwamp                   =civ.getBaseTerrain(0,8)  --Swa
object.bJungle                  =civ.getBaseTerrain(0,9)  --Jun
object.bOcean                   =civ.getBaseTerrain(0,10)  --Oce

-- Terrain
-- recommended prefix 't'

object.tDesert                  =civ.getTerrain(0,0,0)
object.tOasis                   =civ.getTerrain(0,0,1) -- Fish Resource
object.tDesertOil               =civ.getTerrain(0,0,2) -- Whale Resource
object.tPlains                  =civ.getTerrain(0,1,0)
object.tBuffalo                 =civ.getTerrain(0,1,1) -- Fish Resource
object.tWheat                   =civ.getTerrain(0,1,2) -- Whale Resource
object.tGrassland               =civ.getTerrain(0,2,0)
object.tForest                  =civ.getTerrain(0,3,0)
object.tPheasant                =civ.getTerrain(0,3,1) -- Fish Resource
object.tSilk                    =civ.getTerrain(0,3,2) -- Whale Resource
object.tHills                   =civ.getTerrain(0,4,0)
object.tCoal                    =civ.getTerrain(0,4,1) -- Fish Resource
object.tWine                    =civ.getTerrain(0,4,2) -- Whale Resource
object.tMountains               =civ.getTerrain(0,5,0)
object.tGold                    =civ.getTerrain(0,5,1) -- Fish Resource
object.tIron                    =civ.getTerrain(0,5,2) -- Whale Resource
object.tTundra                  =civ.getTerrain(0,6,0)
object.tGame                    =civ.getTerrain(0,6,1) -- Fish Resource
object.tFurs                    =civ.getTerrain(0,6,2) -- Whale Resource
object.tGlacier                 =civ.getTerrain(0,7,0)
object.tIvory                   =civ.getTerrain(0,7,1) -- Fish Resource
object.tGlacierOil              =civ.getTerrain(0,7,2) -- Whale Resource
object.tSwamp                   =civ.getTerrain(0,8,0)
object.tPeat                    =civ.getTerrain(0,8,1) -- Fish Resource
object.tSpice                   =civ.getTerrain(0,8,2) -- Whale Resource
object.tJungle                  =civ.getTerrain(0,9,0)
object.tGems                    =civ.getTerrain(0,9,1) -- Fish Resource
object.tFruit                   =civ.getTerrain(0,9,2) -- Whale Resource
object.tOcean                   =civ.getTerrain(0,10,0)
object.tFish                    =civ.getTerrain(0,10,1) -- Fish Resource
object.tWhales                  =civ.getTerrain(0,10,2) -- Whale Resource

-- Text
-- You might find it easier to keep much of your events text here
-- Remember, you can place %STRING1, %STRING2, etc. in your text and
-- use text.substitute to insert the actual values in the event, instead
-- of splitting the text into multiple parts
-- recommended prefix 'x'



-- Flag and Counter Definitions
-- Flags and counters have to be defined somewhere, and this
-- is as good a place as any






-- this will give you an if you try to access a key not entered into
-- the object table, which could be helpful for debugging, but it
-- means that no nil value can ever be returned for table object
-- If you need that ability, comment out this section
setmetatable(object,{__index = function(myTable,key)
    error("The object table doesn't have a value associated with "..tostring(key)..".") end})

return object
