local gen = require("generalLibrary")
local object = require("object")
local keyboard = require("keyboard")
local helpKeySettings = require("helpKeySettings")
local munitionsSettings = require("munitionsSettings")
local logSettings = require("logSettings")
local simpleSettings = require("simpleSettings")
local diplomacySettings = require("diplomacySettings")
local text = require("text")




local keyPressFunctions = {}



-- Save the instructions for each key press as a function
-- in the table keyPressFunctions, indexed by keyID
-- (This system means that there doesn't have to be a giant
-- list of if statements to check every time a key is pressed
-- use the function generalKeyPress if it doesn't make sense
-- to split the function into individual keys

local function inRectangle(tile,xMin,xMax,yMin,yMax)
    local x = tile.x
    local y = tile.y
    return xMin <= x and x <=xMax and yMin <= y and y <=yMax
end

local region={}
region.italy = {
{xMin=36 , xMax=44, yMin=18 , yMax=38 },
{xMin=38 , xMax=50 , yMin=28 , yMax=46 },
{xMin=46 , xMax=54 , yMin=40 , yMax=54 },
}    

region.sicilySardinia = {
{38,46,50,58},
{31,37,33,47},
}

local function inRegion(object, regionTable)
	local tile = nil
	if civ.isTile(object) then
		tile = object
	elseif civ.isCity(object) then
		tile = object.location
	elseif civ.isUnit(object) then
		tile = object.location
	else
		error("inRegion expected a tile, city, or unit as the first argument.")
	end
	for __,rectangleSpec in pairs(regionTable) do
		if inRectangle(tile,rectangleSpec.xMin or rectangleSpec[1],
			rectangleSpec.xMax or rectangleSpec[2],
			rectangleSpec.yMin or rectangleSpec[3],
			rectangleSpec.yMax or rectangleSpec[4]) then
			return true
		end
	end
	return false
end

local iberiaPolygon = {{1,59},{0,58},{0,40},{0,22},{0,10},{7,11},{9,15},{15,21},{17,23},{17,25},{21,29},{24,32},{22,40},{21,47},{21,55},{14,60},{6,60},doesNotCrossThisX=27}
local egyptPolygon = {{47,79},{47,67},{52,62},{59,63},{64,66},{70,64},{75,63},{81,63},{82,74},{81,79},doesNotCrossThisX=2}

local function inHomesteadRome(tile,distance)
  for city in civ.iterateCities() do
    if city.originalOwner == object.pRomans and city.owner == object.pRomans
      and gen.distance(tile,city) <= distance then
      return true
    end
  end
  -- if we get here, no city is close enough
  return false
end

keyPressFunctions[keyboard.zero] = function()

end

keyPressFunctions[keyboard.one] = function()
    text.openArchive()
end
keyPressFunctions[keyboard.two] = function()
    diplomacySettings.diplomacyMenu()
end
keyPressFunctions[keyboard.three] = function()

end
keyPressFunctions[keyboard.four] = function()

end
keyPressFunctions[keyboard.five] = function()

end
keyPressFunctions[keyboard.six] = function()

end
keyPressFunctions[keyboard.seven] = function()

end
keyPressFunctions[keyboard.eight] = function()
  civ.ui.text("The current tile is in region.italy: "..tostring(
    inRegion(civ.getCurrentTile(),region.italy)))
    civ.ui.text("The current tile is in Egypt: "..tostring(
    gen.inPolygon(civ.getCurrentTile(),egyptPolygon)))
end
keyPressFunctions[keyboard.nine] = function()
  civ.ui.text("The current tile is in region.sicilySardinia: "..tostring(
    inRegion(civ.getCurrentTile(),region.sicilySardinia)))
    civ.ui.text("The current tile is in Iberia: "..tostring(
    gen.inPolygon(civ.getCurrentTile(),iberiaPolygon)))
  civ.ui.text("The current tile is in 'Homestead Rome': "..tostring(
    inHomesteadRome(civ.getCurrentTile(),3)))
end
keyPressFunctions[keyboard.k] = function()
    if civ.getActiveUnit() then
        munitionsSettings.primaryAttack(civ.getActiveUnit())
    end
end
keyPressFunctions[keyboard.u] = function()
    if civ.getActiveUnit() then
        munitionsSettings.secondaryAttack(civ.getActiveUnit())
    end
end
keyPressFunctions[keyboard.h] = function()
    if civ.getActiveUnit() then
        civ.sleep(100)
        munitionsSettings.payloadRestrictionCheck(civ.getActiveUnit())
    end
end
keyPressFunctions[keyboard.tab] = function()
   helpKeySettings.doHelpKey() 
end
keyPressFunctions[keyboard.escape] = function()
    return logSettings.combatReportFunction()
end
keyPressFunctions[keyboard.backspace] = function()

end
keyPressFunctions[keyboard.w] = function()
    if simpleSettings.enableCustomUnitSelection then
        gen.betterUnitManualWait()
    end
end

-- Use this if it makes sense to group several keys
-- into a single event
local function generalKeyPress(keyID)

end

local function doKeyPress(keyID)
    if keyPressFunctions[keyID] then
        keyPressFunctions[keyID]()
    end
    generalKeyPress(keyID)
end

return {doKeyPress = doKeyPress}
