local object = require("object")
local onTurn = {}
local evenTurnLeader = "Scipio"
local oddTurnLeader = "Fabius"
local chariotSquare = civ.getTile(37,15,0)
local barbTable = {
{location = {44,12}, unit = object.uArchers},
{location = {35,39}, unit = object.uHorsemen},
{location = {64,16}, unit = object.uHorsemen},
}-- close barbTable

local seleucidRulers = {
[-281] = {name = "Antiochus I Soter", female = false},
[-278] = {name = "Antiochus I Soter", female = false}, -- this is the year the game starts
[-261] = {name = "Antiochus II Theos", female = false},
[-246] = {name = "Seleucus II Callinicus", female = false},
[-225] = {name = "Seleucus III Ceraunus", female = false},
-- this makes the point
[-126] = {name = "Cleopatra Thea", female = true},
-- have a female ruler to test, though
}--close seleucidRulers


function onTurn.onTurn(turn)
    if seleucidRulers[civ.getGameYear()] then
        -- if there is no entry for this index, it returns nil, which the if statement counts as false.
        object.pSeleucidGreeks.leader.name = seleucidRulers[civ.getGameYear()].name
        object.pSeleucidGreeks.leader.female = seleucidRulers[civ.getGameYear()].female
    end --if seleucidRulers[civ.getGameYear()]
    if turn % 2 == 0 then
        -- We only get here if the turn is even
        object.pRomans.leader.name = evenTurnLeader
    else
        -- We only get here if the turn is odd
        object.pRomans.leader.name = oddTurnLeader
    end
    if (object.lMilan.city and object.lMilan.city.owner == object.pCelts) and
        (chariotSquare.defender == nil or chariotSquare.defender == object.pCelts) and
        not object.pCelts.isHuman then
        local newChariot = civ.createUnit(object.uChariot, object.pCelts, chariotSquare)
        newChariot.veteran = false
        newChariot.homeCity = nil
    end
    for __, barbCreate in pairs(barbTable) do
        local tile = civ.getTile(barbCreate.location[1],barbCreate.location[2],0)
        --print(__,barbCreate.location[1],barbCreate.location[2],0)
        if tile.defender == object.pBarbarians or tile.defender == nil then
            civ.createUnit(barbCreate.unit,object.pBarbarians,tile)
        end
    end
    for unit in civ.iterateUnits() do
        if unit.location.baseTerrain == object.bDesert then
            local newDamage = math.floor(unit.hitpoints/2)
            unit.damage = unit.damage+newDamage
        end
    end
end

return onTurn
