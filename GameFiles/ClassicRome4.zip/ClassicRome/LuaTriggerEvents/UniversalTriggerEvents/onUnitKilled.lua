local unitKilledEvents = {}
local object = require("object")
local text = require("text")
local gen = require("generalLibrary")
-- This will only run when a unit is killed in combat (i.e. not when an event
-- 'kills' a unit)
-- note that if the aggressor loses, aggressor.location will not work
--
local elephantCampaignCost = 5
local catapultCampaignCost = 4
local twoMoveCampaignCost = 3
local defaultCampaignCost = 1
--local campaignCost = 1
local modernUnits={
    [object.uArmor.id]=true,
    [object.uMechInf.id]=true,
    [object.uHelicopter.id]=true,
    [object.uParatroopers.id]=true,
}
local function nearestFriendlyCity(tile,tribe)
  local nearestCitySoFar = nil
  local bestDistanceSoFar = 100000
  for city in civ.iterateCities() do
    if city.owner == tribe and gen.distance(tile,city) < bestDistanceSoFar then
      nearestCitySoFar = city
      bestDistanceSoFar = gen.distance(tile,city)
    end
  end
  return nearestCitySoFar
end
console.nearestFriendlyCity = nearestFriendlyCity
local caravanShieldFraction = 0.7
function unitKilledEvents.unitKilledInCombat(loser ,winner ,aggressor,victim,loserLocation,winnerVetStatus,loserVetStatus)
    if loser.type == object.uSettlers then
        local newSettler = civ.createUnit(object.uSettlers, winner.owner, winner.location)
        newSettler.homeCity = nil
        newSettler.moveSpent = 255
        newSettler.damage = newSettler.type.hitpoints - 5
    end
    --loser.owner.money = math.max(loser.owner.money -campaignCost,0)
    --winner.owner.money = math.max(winner.owner.money-campaignCost,0)
    if loser.hitpoints <= 0 then
        for __,unit in pairs({winner,loser}) do
            if unit.type == object.uElephant then
                unit.owner.money = math.max(unit.owner.money-elephantCampaignCost,0)
            elseif unit.type == object.uCatapult then
                unit.owner.money = math.max(unit.owner.money-catapultCampaignCost,0)
            elseif unit.type.move == 2*totpp.movementMultipliers.aggregate then
                unit.owner.money = math.max(unit.owner.money-twoMoveCampaignCost,0)
            else
                unit.owner.money = math.max(unit.owner.money-defaultCampaignCost,0)
            end
        end
    end
    if modernUnits[winner.type.id] and winner.owner.isHuman then
        text.simple("I didn't know the "..winner.owner.name.." used "..winner.type.name..".","Historian")
    end
    if loser.type.role == 7 then
        local nearestCity = nearestFriendlyCity(loserLocation,winner.owner)
        if nearestCity then
          local shieldBonus = math.floor(loser.type.cost*civ.cosmic.shieldRows*caravanShieldFraction)
          nearestCity.shields = nearestCity.shields+shieldBonus
          if winner.owner == civ.getPlayerTribe() then
            text.simple(text.substitute("Our %STRING1 unit has defeated a %STRING2 unit.  %STRING3 shields of plunder has been added to %STRING4's production box.",{winner.type.name,loser.type.name,shieldBonus,nearestCity.name}))
          end
        end
        if not winnerVetStatus and math.random() < 0.33 then
          winner.damage = winner.type.hitpoints - 1
          if loser.owner == civ.getPlayerTribe() then
            text.simple(text.substitute("Our enemies have dispersed to plunder our defeated %STRING1.  We should counterattack while they are disorganized.",
            {loser.type.name}))
          end
          if winner.owner == civ.getPlayerTribe() then
            text.simple(text.substitute("The men of our %STRING1 unit have dispersed to plunder the %STRING2 %STRING3.  We are vulnerable to counterattack.",
            {winner.type.name,loser.owner.adjective,loser.type.name}))
          end
        end
    end
end


-- This will run any time a unit is killed, either in combat or by events
--
function unitKilledEvents.unitDefeated(loser,winner,aggressor,victim,loserLocation,winnerVetStatus,loserVetStatus)

end

-- this happens whenever a unit 'dies', regardless of combat, as long as it is not replaced
function unitKilledEvents.unitDeath(dyingUnit)

end

-- this happens whenever a unit 'dies', but not through combat (or 'defeat')
function unitKilledEvents.unitDeathOutsideCombat(dyingUnit)

end
-- this happens if a unit is deleted (either through combat death, or by some other event,
-- but not if the unit is disbanded)
-- If the unit isn't being replaced, replacingUnit is nil
function unitKilledEvents.unitDeleted(deletedUnit,replacingUnit)

end

return unitKilledEvents

