local gen = require("generalLibrary")
local object = require("object")
local text = require("text")

local cityTaken = {}


-- countUnits(unitType,tribe) --> integer
-- counts the number of unitType owned by the tribe
--  unitType is a unitTypeObject
--  tribe is a tribeObject
local function countUnits(unitType,tribe)
  local countSoFar = 0
  for unit in civ.iterateUnits() do
    if unit.owner == tribe and unit.type == unitType then
      countSoFar = countSoFar+1
    end
  end
  return countSoFar
end

local minimumLegions = 6

function cityTaken.onCityTaken(city,defender)
    if defender == object.pRomans and 
      object.lRome.city and 
      object.lRome.city.owner == object.pRomans then
      local legionCount = countUnits(object.uLegion,object.pRomans)
      if legionCount < minimumLegions then
        gen.createUnit(object.uLegion,object.pRomans,object.lRome,
                    {count = minimumLegions-legionCount})
        if city.owner == civ.getPlayerTribe() or defender == civ.getPlayerTribe() then
          text.simple(text.substitute("Alarmed by the loss of %STRING1, the %STRING2 quickly raise %STRING3 new %STRING5 units to face the %STRING4 threat.",
            {city.name, object.pRomans.name, minimumLegions-legionCount,city.owner.adjective,
            object.uLegion.name}))
        end
      end
    end

end

return cityTaken
